using IbmAs400Workbench.Models;
using IbmAs400Workbench.Services;
using Microsoft.AspNetCore.Mvc;

namespace IbmAs400Workbench.Controllers;

/// <summary>
/// Controller for the IBM i (AS400) COBOL Business Object Direct Testing Workbench.
/// Handles dynamic test execution across all 4 bypass methods with ZERO appsettings.json dependency.
/// </summary>
public class BoWorkbenchController : Controller
{
    private readonly IIbmBoExecutionService _executionService;
    private readonly ICobolBufferService _bufferService;
    private readonly ILogger<BoWorkbenchController> _logger;

    public BoWorkbenchController(
        IIbmBoExecutionService executionService,
        ICobolBufferService bufferService,
        ILogger<BoWorkbenchController> logger)
    {
        _executionService = executionService;
        _bufferService = bufferService;
        _logger = logger;
    }

    /// <summary>
    /// Displays the main diagnostic workbench screen.
    /// </summary>
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    /// <summary>
    /// METHOD A: DB2 Stored Procedure Wrapper Call
    /// </summary>
    [HttpPost]
    [Route("BoWorkbench/ExecuteStoredProc")]
    public async Task<IActionResult> ExecuteStoredProc([FromBody] BoExecutionRequest request, CancellationToken cancellationToken)
    {
        if (request == null)
        {
            return BadRequest(new { error = "Execution request cannot be null." });
        }

        try
        {
            var result = await _executionService.ExecuteStoredProcAsync(request, cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing Stored Procedure call");
            return StatusCode(500, new BoDiagnosticResponse
            {
                Status = "ERROR",
                ErrorMessage = ex.Message,
                MethodUsed = "Method A: DB2 Stored Procedure Wrapper Call"
            });
        }
    }

    /// <summary>
    /// METHOD B: Direct Dynamic Program Call (QSYS2.QCMDEXC)
    /// </summary>
    [HttpPost]
    [Route("BoWorkbench/ExecuteQcmdexc")]
    public async Task<IActionResult> ExecuteQcmdexc([FromBody] BoExecutionRequest request, CancellationToken cancellationToken)
    {
        if (request == null)
        {
            return BadRequest(new { error = "Execution request cannot be null." });
        }

        try
        {
            var result = await _executionService.ExecuteQcmdexcAsync(request, cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing QCMDEXC call");
            return StatusCode(500, new BoDiagnosticResponse
            {
                Status = "ERROR",
                ErrorMessage = ex.Message,
                MethodUsed = "Method B: Direct Dynamic Program Call (QSYS2.QCMDEXC)"
            });
        }
    }

    /// <summary>
    /// METHOD C: SSH / PASE Command Invocation
    /// </summary>
    [HttpPost]
    [Route("BoWorkbench/ExecuteSshPase")]
    public async Task<IActionResult> ExecuteSshPase([FromBody] BoExecutionRequest request, CancellationToken cancellationToken)
    {
        if (request == null)
        {
            return BadRequest(new { error = "Execution request cannot be null." });
        }

        try
        {
            var result = await _executionService.ExecuteSshPaseAsync(request, cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing SSH / PASE call");
            return StatusCode(500, new BoDiagnosticResponse
            {
                Status = "ERROR",
                ErrorMessage = ex.Message,
                MethodUsed = "Method C: SSH / PASE Command Invocation"
            });
        }
    }

    /// <summary>
    /// METHOD D: Free-Form Raw DB2 SQL Execution
    /// </summary>
    [HttpPost]
    [Route("BoWorkbench/ExecuteRawSql")]
    public async Task<IActionResult> ExecuteRawSql([FromBody] RawSqlRequest request, CancellationToken cancellationToken)
    {
        if (request == null)
        {
            return BadRequest(new { error = "SQL request cannot be null." });
        }

        try
        {
            var result = await _executionService.ExecuteRawSqlAsync(request, cancellationToken);
            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error executing raw SQL query");
            return StatusCode(500, new BoDiagnosticResponse
            {
                Status = "ERROR",
                ErrorMessage = ex.Message,
                MethodUsed = "Method D: Raw DB2 SQL Execution Workbench"
            });
        }
    }

    /// <summary>
    /// Helper: Dynamically calculates fixed-width padded buffer preview from copybook field rows.
    /// </summary>
    [HttpPost]
    [Route("BoWorkbench/CalculateBufferPreview")]
    public IActionResult CalculateBufferPreview([FromBody] List<CopybookFieldDefinition> fields, [FromQuery] int minLength = 0)
    {
        var validation = _bufferService.ValidateLayout(fields);
        if (!validation.IsValid)
        {
            return BadRequest(new { error = validation.ErrorMessage });
        }

        string paddedBuffer = _bufferService.BuildInputBuffer(fields, minLength);
        return Ok(new
        {
            buffer = paddedBuffer,
            length = paddedBuffer.Length,
            fieldsCount = fields?.Count ?? 0
        });
    }

    /// <summary>
    /// Queries QSYS2.JOBLOG_INFO for the current or specified AS400 job.
    /// </summary>
    [HttpPost]
    [Route("BoWorkbench/GetJobLogs")]
    public async Task<IActionResult> GetJobLogs([FromBody] As400ConnectionRequest connection, [FromQuery] string? jobName, CancellationToken cancellationToken)
    {
        try
        {
            var logs = await _executionService.FetchJobLogsAsync(connection, jobName, cancellationToken);
            return Ok(logs);
        }
        catch (Exception ex)
        {
            return StatusCode(500, new { error = ex.Message });
        }
    }
}
