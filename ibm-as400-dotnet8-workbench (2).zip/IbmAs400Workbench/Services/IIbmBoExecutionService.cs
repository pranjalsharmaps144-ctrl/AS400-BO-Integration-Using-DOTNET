using IbmAs400Workbench.Models;

namespace IbmAs400Workbench.Services;

/// <summary>
/// Service interface for dispatching IBM i (AS400) program calls across all 4 bypass techniques.
/// </summary>
public interface IIbmBoExecutionService
{
    /// <summary>
    /// Method A: DB2 Stored Procedure Wrapper Call
    /// Invokes CALL LIBR.PROC_NAME(?, ?, ...) passing IN/OUT fixed-width string buffers.
    /// </summary>
    Task<BoDiagnosticResponse> ExecuteStoredProcAsync(BoExecutionRequest request, CancellationToken cancellationToken = default);

    /// <summary>
    /// Method B: Direct Dynamic Program Call
    /// Invokes QSYS2.QCMDEXC('CALL PGM(LIBR/BO_PGM) PARM(...)') or direct dynamic SQL CALL.
    /// </summary>
    Task<BoDiagnosticResponse> ExecuteQcmdexcAsync(BoExecutionRequest request, CancellationToken cancellationToken = default);

    /// <summary>
    /// Method C: SSH / PASE Command Invocation
    /// Connects via SSH using Renci.SshNet and executes: system "CALL PGM(LIBR/BO_PGM) PARM('...')"
    /// </summary>
    Task<BoDiagnosticResponse> ExecuteSshPaseAsync(BoExecutionRequest request, CancellationToken cancellationToken = default);

    /// <summary>
    /// Method D: Free-Form Raw DB2 SQL Execution
    /// Executes diagnostic queries against DB2 tables and QSYS2 catalog/views.
    /// </summary>
    Task<BoDiagnosticResponse> ExecuteRawSqlAsync(RawSqlRequest request, CancellationToken cancellationToken = default);

    /// <summary>
    /// Fetches job log messages from QSYS2.JOBLOG_INFO() for diagnostic deep-dive.
    /// </summary>
    Task<List<JobLogEntry>> FetchJobLogsAsync(As400ConnectionRequest connection, string? jobIdentifier = null, CancellationToken cancellationToken = default);
}
