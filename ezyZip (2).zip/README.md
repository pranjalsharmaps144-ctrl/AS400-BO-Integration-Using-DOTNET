# IBM i (AS400 / DB2) and .NET 8 COBOL Business Object Direct Testing Workbench

An enterprise-grade ASP.NET Core 8.0 MVC diagnostic and testing workbench engineered to verify and benchmark calling IBM i (AS400) COBOL Business Object (BO) programs directly **WITHOUT** using IBM MQ.

---

## 1. Architectural Overview: Bypassing IBM MQ

In traditional legacy architectures, distributed frontends publish fixed-width request buffers to an IBM MQ Request Queue. A trigger monitor or batch daemon on the AS400 dequeues the message, calls the COBOL program passing the buffer via `LINKAGE SECTION`, and enqueues the response back to a Reply Queue.

### Why Bypass MQ?
- **Sub-10ms Latency**: Eliminates multi-hop queue persistence, channel sync, and polling delays.
- **Synchronous Two-Way Request/Response**: Direct thread-bound execution with instant SQLState / return code propagation.
- **Immediate Job Log Diagnostics**: Uncovers the exact AS400 job (`QZDASOINIT` or `QP0ZSPWP`) and job messages via `QSYS2.JOBLOG_INFO()`.
- **Zero appsettings.json**: Fully dynamic credentials, endpoints, libraries, and copybook definitions passed from runtime UI.

---

## 2. The 4 Bypass Techniques Tested by this Workbench

### Method A: DB2 Stored Procedure Wrapper (Recommended for High Throughput)
Creates a thin external DB2 SQL stored procedure wrapper that points directly to the compiled COBOL program object (`*PGM`).

#### AS400 DB2 Wrapper DDL:
```sql
CREATE OR REPLACE PROCEDURE PRODLIB.SP_CALL_POLINQ (
    IN  P_IN_BUFFER   VARCHAR(500),
    OUT P_OUT_BUFFER  VARCHAR(500),
    OUT P_RET_CODE    VARCHAR(10)
)
LANGUAGE COBOL
DETERMINISTIC
NO SQL
EXTERNAL NAME 'PRODLIB/POLINQ'
PARAMETER STYLE GENERAL;
```
- **Driver**: IBM i Access ODBC Driver or `IBM.Data.Db2.Core`.
- **Syntax**: `CALL PRODLIB.SP_CALL_POLINQ(?, ?, ?)`.
- **Underlying AS400 Job**: `QZDASOINIT` in subsystem `QUSRWRK`.

---

### Method B: Direct Dynamic Program Call (QSYS2.QCMDEXC)
Invokes IBM i CL commands directly through DB2 without requiring any pre-created stored procedures.
```sql
CALL QSYS2.QCMDEXC('CALL PGM(PRODLIB/POLINQ) PARM(''INQ1001POL-9482104'')')
```
- **Optional *LDA Initialization**:
  ```sql
  CALL QSYS2.QCMDEXC('CHGDTAARA DTAARA(*LDA (1 20)) VALUE(''USER01    CORP01BR01'')')
  ```
- **Advantage**: Requires zero deployment or DDL changes on the IBM i partition.

---

### Method C: SSH / PASE Command Invocation (Renci.SshNet)
Connects directly to the IBM i Portable Application Solutions Environment (PASE) via SSH (Port 22) and executes the native ILE program using the `system` utility:
```bash
system "CALL PGM(PRODLIB/POLINQ) PARM('INQ1001POL-9482104')"
```
- **Underlying AS400 Job**: `QP0ZSPWP` in subsystem `QSYSWRK`.
- **Advantage**: Bypasses corporate firewall restrictions blocking DRDA/DB2 ports (446 / 8471).

---

### Method D: Raw DB2 SQL Execution & Job Log Analyzer
Interactive query console to verify connectivity, inspect system catalogs, and retrieve real-time job log messages:
```sql
-- Query real-time job log for active QZDASOINIT server job
SELECT ORDINAL_POSITION, MESSAGE_ID, MESSAGE_TYPE, SEVERITY, MESSAGE_TEXT, MESSAGE_SECOND_LEVEL_TEXT
FROM TABLE(QSYS2.JOBLOG_INFO('*')) AS A
ORDER BY ORDINAL_POSITION DESC
FETCH FIRST 50 ROWS ONLY;
```

---

## 3. Diagnosing the #1 Pitfall: Green-Screen / Terminal Hangs

When testing COBOL BOs directly, the most frequent failure mode is an **indefinite hang** (timeout). This workbench automatically detects and flags this heuristic:

> **DIAGNOSTIC WARNING: Program hung. Likely caused by interactive Display File (DSPF), READ statement on green-screen workstation, or missing Local Data Area (*LDA) initialization in headless QZDASOINIT background job.**

### Root Causes & Remediation Steps:
1. **Interactive Display File (DSPF)**:
   - If the COBOL program contains `READ WORKSTATION` or `EXFMT SCREEN-RECORD`, it attempts to prompt a 5250 green-screen device.
   - Background jobs (`QZDASOINIT`) have no terminal device attached; the program blocks waiting for input indefinitely.
   - **Fix**: Decouple interactive logic. Have the screen program call a headless business logic subprogram (`*MODULE` or `*SRVPGM`).
2. **Missing Local Data Area (*LDA)**:
   - Systems like CSC Life Asia, Silverlake, and Bancs read operating parameters (Company, User ID, Branch, Accounting Date) from `*LDA` upon entry.
   - In headless DB2 jobs, `*LDA` is blank. The program throws `CPA5305` or inquiry messages to `QSYSOPR`.
   - **Fix**: Use Method B to pre-populate `*LDA` with `CHGDTAARA DTAARA(*LDA (1 50)) VALUE(...)`.
3. **MCH3601 (Pointer Not Set for Location Referenced)**:
   - Occurs when the `.NET` buffer length is shorter than the COBOL `LINKAGE SECTION 01` record layout.
   - **Fix**: Use this workbench's **Copybook Field Mapper Table** to ensure exact byte-for-byte alignment.

---

## 4. Running the .NET 8 Project

### Prerequisites:
- .NET 8.0 SDK (`dotnet --version` >= 8.0.100)
- IBM i Access Client Solutions ODBC Driver (optional, for live AS400 connections)

### Commands:
```bash
# Restore NuGet dependencies (IBM.Data.Db2.Core, System.Data.Odbc, SSH.NET)
dotnet restore

# Run application on localhost:5000 / https://localhost:5001
dotnet run

# Open browser to:
http://localhost:5000
```
