using IbmAs400Workbench.Models;

namespace IbmAs400Workbench.Services;

/// <summary>
/// Service interface for COBOL copybook fixed-width buffer construction and response parsing.
/// </summary>
public interface ICobolBufferService
{
    /// <summary>
    /// Builds a single contiguous fixed-width string buffer from mapped copybook fields.
    /// Fills gaps between fields with spaces and applies numeric '0' and alphanumeric ' ' padding.
    /// </summary>
    string BuildInputBuffer(List<CopybookFieldDefinition> fields, int minTotalLength = 0);

    /// <summary>
    /// Deconstructs a returned AS400 raw string buffer into strongly-typed key-value field results.
    /// </summary>
    List<ParsedFieldResult> ParseOutputBuffer(string rawBuffer, List<CopybookFieldDefinition> fields);

    /// <summary>
    /// Validates field definitions for overlapping positions or invalid length boundaries.
    /// </summary>
    (bool IsValid, string? ErrorMessage) ValidateLayout(List<CopybookFieldDefinition> fields);
}
