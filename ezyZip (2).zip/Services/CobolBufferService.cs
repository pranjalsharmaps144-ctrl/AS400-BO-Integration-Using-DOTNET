using System.Text;
using IbmAs400Workbench.Models;

namespace IbmAs400Workbench.Services;

/// <summary>
/// Implementation of COBOL Linkage Section buffer formatting and parsing.
/// Handles EBCDIC fixed-width field alignment, left/right padding, and offset calculations.
/// </summary>
public class CobolBufferService : ICobolBufferService
{
    public string BuildInputBuffer(List<CopybookFieldDefinition> fields, int minTotalLength = 0)
    {
        if (fields == null || fields.Count == 0)
        {
            return minTotalLength > 0 ? new string(' ', minTotalLength) : string.Empty;
        }

        // Sort fields by StartPosition
        var sortedFields = fields.OrderBy(f => f.StartPosition).ToList();

        // Calculate maximum required length
        int maxEnd = sortedFields.Max(f => f.StartPosition + f.Length - 1);
        int finalLength = Math.Max(maxEnd, minTotalLength);

        // Initialize buffer filled with spaces
        char[] buffer = Enumerable.Repeat(' ', finalLength).ToArray();

        foreach (var field in sortedFields)
        {
            int startIdx = field.StartPosition - 1; // 1-based to 0-based
            if (startIdx < 0 || startIdx >= finalLength)
            {
                continue;
            }

            string paddedValue = field.GetPaddedValue();
            for (int i = 0; i < field.Length && (startIdx + i) < finalLength; i++)
            {
                char ch = i < paddedValue.Length ? paddedValue[i] : ' ';
                buffer[startIdx + i] = ch;
            }
        }

        return new string(buffer);
    }

    public List<ParsedFieldResult> ParseOutputBuffer(string rawBuffer, List<CopybookFieldDefinition> fields)
    {
        var results = new List<ParsedFieldResult>();

        if (fields == null || fields.Count == 0 || string.IsNullOrEmpty(rawBuffer))
        {
            return results;
        }

        foreach (var field in fields.OrderBy(f => f.StartPosition))
        {
            int startIdx = field.StartPosition - 1;
            int length = field.Length;

            string extractedRaw = string.Empty;
            string trimmed = string.Empty;

            if (startIdx < rawBuffer.Length)
            {
                int availableLength = Math.Min(length, rawBuffer.Length - startIdx);
                extractedRaw = rawBuffer.Substring(startIdx, availableLength);

                // Pad with spaces if the returned buffer was shorter than expected field definition
                if (extractedRaw.Length < length)
                {
                    extractedRaw = extractedRaw.PadRight(length, ' ');
                }

                trimmed = string.Equals(field.DataType, "Numeric", StringComparison.OrdinalIgnoreCase)
                    ? extractedRaw.TrimStart('0')
                    : extractedRaw.Trim();

                if (string.IsNullOrEmpty(trimmed) && string.Equals(field.DataType, "Numeric", StringComparison.OrdinalIgnoreCase))
                {
                    trimmed = "0";
                }
            }

            results.Add(new ParsedFieldResult
            {
                FieldName = field.FieldName,
                StartPosition = field.StartPosition,
                Length = field.Length,
                DataType = field.DataType,
                RawValue = extractedRaw,
                TrimmedValue = trimmed
            });
        }

        return results;
    }

    public (bool IsValid, string? ErrorMessage) ValidateLayout(List<CopybookFieldDefinition> fields)
    {
        if (fields == null || fields.Count == 0)
        {
            return (true, null);
        }

        var sorted = fields.OrderBy(f => f.StartPosition).ToList();
        for (int i = 0; i < sorted.Count - 1; i++)
        {
            var current = sorted[i];
            var next = sorted[i + 1];

            int currentEnd = current.StartPosition + current.Length - 1;
            if (currentEnd >= next.StartPosition)
            {
                return (false, $"Field '{current.FieldName}' (pos {current.StartPosition}-{currentEnd}) overlaps with field '{next.FieldName}' (pos {next.StartPosition}).");
            }
        }

        return (true, null);
    }
}
