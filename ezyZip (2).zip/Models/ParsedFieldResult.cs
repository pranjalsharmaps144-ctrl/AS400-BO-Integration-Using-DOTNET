namespace IbmAs400Workbench.Models;

/// <summary>
/// Represents a parsed copybook field extracted from the AS400 output buffer.
/// </summary>
public class ParsedFieldResult
{
    public string FieldName { get; set; } = string.Empty;
    public int StartPosition { get; set; }
    public int Length { get; set; }
    public string DataType { get; set; } = "Char";
    public string RawValue { get; set; } = string.Empty;
    public string TrimmedValue { get; set; } = string.Empty;
}
