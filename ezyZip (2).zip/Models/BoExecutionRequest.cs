namespace IbmAs400Workbench.Models;

/// <summary>
/// Encapsulates a complete BO Program Execution request across all 4 bypass methods.
/// Fully dynamic - zero dependency on appsettings.json.
/// </summary>
public class BoExecutionRequest
{
    /// <summary>
    /// Connection credentials and AS400 endpoints
    /// </summary>
    public As400ConnectionRequest Connection { get; set; } = new();

    /// <summary>
    /// Execution Method: "StoredProcedure", "Qcmdexc", "SshPase", "RawSql"
    /// </summary>
    public string ExecutionMethod { get; set; } = "StoredProcedure";

    /// <summary>
    /// Target AS400 Library where the COBOL BO Program resides (e.g., LIBR, PRODLIB, QGPL)
    /// </summary>
    public string TargetLibrary { get; set; } = "LIBR";

    /// <summary>
    /// Business Object Program Name (e.g., POLINQ, CUSTBO, BO_PGM)
    /// </summary>
    public string ProgramName { get; set; } = "BO_PGM";

    /// <summary>
    /// Procedure Name if invoking via DB2 Stored Procedure Wrapper (e.g., SP_CALL_BO)
    /// </summary>
    public string? ProcedureName { get; set; } = "SP_CALL_BO";

    /// <summary>
    /// Input Mode: "Raw" or "Fields"
    /// </summary>
    public string InputMode { get; set; } = "Fields";

    /// <summary>
    /// Raw unparsed input buffer passed directly if InputMode == "Raw"
    /// </summary>
    public string? RawInputBuffer { get; set; }

    /// <summary>
    /// Dynamic field definitions for assembling the input buffer
    /// </summary>
    public List<CopybookFieldDefinition> InputFields { get; set; } = new();

    /// <summary>
    /// Dynamic field definitions for parsing the returned output buffer
    /// </summary>
    public List<CopybookFieldDefinition> OutputFields { get; set; } = new();

    /// <summary>
    /// Expected length of the output buffer allocated by caller
    /// </summary>
    public int ExpectedOutputLength { get; set; } = 500;

    /// <summary>
    /// Free-form SQL query for Method D
    /// </summary>
    public string? RawSqlStatement { get; set; }

    /// <summary>
    /// Custom XML payload for Method E: XMLSERVICE Direct Program Call
    /// </summary>
    public string? XmlPayload { get; set; }

    /// <summary>
    /// XMLSERVICE Stored Procedure Name (e.g., iPLUG512K, iPLUG65K, iPLUG32K, iPLUG4M)
    /// </summary>
    public string XmlProcedureName { get; set; } = "iPLUG512K";

    /// <summary>
    /// Library where XMLSERVICE is installed (standard: QXMLSERV or XMLSERVICE)
    /// </summary>
    public string XmlServiceLibrary { get; set; } = "QXMLSERV";

    /// <summary>
    /// Optional parameter: Pass *LDA (Local Data Area) string initialization before program call
    /// </summary>
    public string? LocalDataAreaInitialization { get; set; }

    /// <summary>
    /// If true or host unreachable in testing sandbox, runs AS400 emulation engine with realistic COBOL responses and diagnostics.
    /// </summary>
    public bool EmulateIfUnreachable { get; set; } = true;
}
