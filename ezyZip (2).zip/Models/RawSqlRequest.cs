namespace IbmAs400Workbench.Models;

/// <summary>
/// Free-form DB2 SQL execution request model for testing connection health,
/// inspecting catalog views (QSYS2.SYSTABLES, QSYS2.ROUTINES), and querying job logs.
/// </summary>
public class RawSqlRequest
{
    public As400ConnectionRequest Connection { get; set; } = new();
    public string SqlStatement { get; set; } = "SELECT CURRENT_SERVER, CURRENT_USER, CURRENT_TIMEZONE FROM SYSIBM.SYSDUMMY1";
    public int MaxRows { get; set; } = 100;
}
