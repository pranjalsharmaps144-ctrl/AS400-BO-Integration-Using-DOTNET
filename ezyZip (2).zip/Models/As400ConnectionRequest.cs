using System.ComponentModel.DataAnnotations;
using System.Text;

namespace IbmAs400Workbench.Models;

/// <summary>
/// Encapsulates connection and authentication parameters for IBM i (AS400).
/// ZERO dependency on appsettings.json: all properties are populated dynamically from UI inputs.
/// </summary>
public class As400ConnectionRequest
{
    [Required]
    [Display(Name = "AS400 Host / IP")]
    public string Host { get; set; } = string.Empty;

    [Display(Name = "DB2 Port")]
    public int Port { get; set; } = 446; // 446 (DRDA/DDCS), 8471 (DB2 Database Server), 22 (SSH/PASE)

    [Required]
    [Display(Name = "Username")]
    public string Username { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Password)]
    [Display(Name = "Password")]
    public string Password { get; set; } = string.Empty;

    [Display(Name = "Default Collection / Library")]
    public string? DefaultCollection { get; set; } = "QGPL";

    [Display(Name = "Library List (INLLIBL)")]
    public string? LibraryList { get; set; } = "QTEMP,QGPL";

    [Display(Name = "Naming Convention")]
    public string NamingConvention { get; set; } = "System"; // "System" (*SYS with /) or "SQL" (*SQL with .)

    [Display(Name = "Connection Timeout (Seconds)")]
    public int TimeoutSeconds { get; set; } = 30;

    [Display(Name = "Driver Type")]
    public string DriverType { get; set; } = "ODBC"; // "ODBC" (IBM i Access ODBC Driver) or "DB2NET" (IBM.Data.DB2.Core)

    /// <summary>
    /// Builds dynamic ODBC connection string for IBM i Access Client Solutions driver.
    /// Does not read from any configuration files.
    /// </summary>
    public string BuildOdbcConnectionString()
    {
        var builder = new StringBuilder();
        builder.Append($"DRIVER={{IBM i Access ODBC Driver}};");
        builder.Append($"SYSTEM={Host};");
        builder.Append($"UID={Username};");
        builder.Append($"PWD={Password};");

        if (Port > 0)
        {
            builder.Append($"PORT={Port};");
        }

        // System naming (*SYS) enables library list resolution without schema prefixes
        if (string.Equals(NamingConvention, "System", StringComparison.OrdinalIgnoreCase))
        {
            builder.Append("NAM=1;"); // 1 = System naming (*SYS, uses / and *LIBL)
        }
        else
        {
            builder.Append("NAM=0;"); // 0 = SQL naming (*SQL, uses .)
        }

        // Library list resolution (INLLIBL)
        if (!string.IsNullOrWhiteSpace(LibraryList))
        {
            var cleanedLibs = LibraryList.Replace(" ", ",");
            builder.Append($"DBQ={cleanedLibs};");
        }
        else if (!string.IsNullOrWhiteSpace(DefaultCollection))
        {
            builder.Append($"DBQ={DefaultCollection};");
        }

        builder.Append($"TIMEOUT={TimeoutSeconds};");
        builder.Append("CMT=0;"); // Commit mode: *NONE (autocommit)
        builder.Append("TRANSLATE=1;"); // Auto translate CCSID / EBCDIC to ASCII/Unicode
        return builder.ToString();
    }

    /// <summary>
    /// Builds dynamic DB2 .NET Core provider connection string.
    /// </summary>
    public string BuildDb2ConnectionString()
    {
        var builder = new StringBuilder();
        builder.Append($"Server={Host}:{Port};");
        builder.Append($"Database={DefaultCollection ?? "QGPL"};");
        builder.Append($"UID={Username};");
        builder.Append($"PWD={Password};");
        builder.Append($"ConnectionTimeout={TimeoutSeconds};");
        return builder.ToString();
    }
}
