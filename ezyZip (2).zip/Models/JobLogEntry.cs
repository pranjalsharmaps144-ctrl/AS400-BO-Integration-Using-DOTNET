namespace IbmAs400Workbench.Models;

/// <summary>
/// Represents an AS400 Job Log record retrieved from QSYS2.JOBLOG_INFO()
/// </summary>
public class JobLogEntry
{
    public int MessageOrdinalNumber { get; set; }
    public string MessageId { get; set; } = string.Empty;
    public string MessageType { get; set; } = string.Empty;
    public int Severity { get; set; }
    public string MessageText { get; set; } = string.Empty;
    public string MessageSecondLevelText { get; set; } = string.Empty;
    public string MessageTimestamp { get; set; } = string.Empty;
    public string FromProgram { get; set; } = string.Empty;
    public string FromLibrary { get; set; } = string.Empty;
    public string ToProgram { get; set; } = string.Empty;
}
