namespace IbmAs400Workbench.Models;

/// <summary>
/// Defines a single field mapping within a fixed-width COBOL copybook structure.
/// </summary>
public class CopybookFieldDefinition
{
    /// <summary>
    /// COBOL field identifier (e.g., WS-POL-NO, WS-RET-CODE)
    /// </summary>
    public string FieldName { get; set; } = string.Empty;

    /// <summary>
    /// 1-based start position in the buffer
    /// </summary>
    public int StartPosition { get; set; } = 1;

    /// <summary>
    /// Length of field in bytes
    /// </summary>
    public int Length { get; set; } = 10;

    /// <summary>
    /// Field type: "Char" (alphanumeric PIC X) or "Numeric" (zoned numeric PIC 9)
    /// </summary>
    public string DataType { get; set; } = "Char";

    /// <summary>
    /// Padding direction: "Right" (for Char) or "Left" (for Numeric)
    /// </summary>
    public string PadDirection { get; set; } = "Right";

    /// <summary>
    /// User supplied input value
    /// </summary>
    public string? Value { get; set; } = string.Empty;

    /// <summary>
    /// Formats and pads the field value according to COBOL fixed-width alignment rules.
    /// </summary>
    public string GetPaddedValue()
    {
        var raw = Value ?? string.Empty;

        // Truncate if exceeds length
        if (raw.Length > Length)
        {
            return raw.Substring(0, Length);
        }

        bool isNumeric = string.Equals(DataType, "Numeric", StringComparison.OrdinalIgnoreCase);

        if (string.Equals(PadDirection, "Left", StringComparison.OrdinalIgnoreCase) || isNumeric)
        {
            // Pad left with '0' for numeric, or space if char left-padded
            char padChar = isNumeric ? '0' : ' ';
            return raw.PadLeft(Length, padChar);
        }
        else
        {
            // Pad right with space for alphanumeric PIC X
            return raw.PadRight(Length, ' ');
        }
    }
}
