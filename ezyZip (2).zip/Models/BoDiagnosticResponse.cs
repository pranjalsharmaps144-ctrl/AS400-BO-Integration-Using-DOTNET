namespace IbmAs400Workbench.Models;

/// <summary>
/// Comprehensive response model containing execution outputs, deep diagnostics,
/// AS400 job logs, and green-screen / hang heuristics.
/// </summary>
public class BoDiagnosticResponse
{
    // ==========================================
    // PANEL 1: RESPONSE & EXECUTION RESULT
    // ==========================================

    /// <summary>
    /// Execution status: "SUCCESS", "ERROR", "AS400_HANG_DETECTED", "TIMEOUT"
    /// </summary>
    public string Status { get; set; } = "UNKNOWN";

    /// <summary>
    /// Total round-trip execution time in milliseconds
    /// </summary>
    public long ElapsedMilliseconds { get; set; }

    /// <summary>
    /// Raw unformatted output buffer returned from COBOL Linkage Section
    /// </summary>
    public string RawOutputBuffer { get; set; } = string.Empty;

    /// <summary>
    /// Raw input buffer sent to the AS400
    /// </summary>
    public string RawInputBufferSent { get; set; } = string.Empty;

    /// <summary>
    /// Parsed key-value field results mapped from OutputFields definition
    /// </summary>
    public List<ParsedFieldResult> ParsedOutputFields { get; set; } = new();

    /// <summary>
    /// SQL State code (e.g., 00000, 42704, 57014)
    /// </summary>
    public string SqlState { get; set; } = "00000";

    /// <summary>
    /// Native AS400 return code or SQL error code
    /// </summary>
    public int ReturnCode { get; set; } = 0;

    /// <summary>
    /// Human-readable error message or exception details
    /// </summary>
    public string? ErrorMessage { get; set; }

    /// <summary>
    /// Execution Method used
    /// </summary>
    public string MethodUsed { get; set; } = string.Empty;

    /// <summary>
    /// Formatted XML payload sent to XMLSERVICE (Method E)
    /// </summary>
    public string? XmlSent { get; set; }

    /// <summary>
    /// Raw XML response received from XMLSERVICE (Method E)
    /// </summary>
    public string? XmlReceived { get; set; }

    // ==========================================
    // PANEL 2: DEEP DIAGNOSTIC & JOB LOG ANALYZER
    // ==========================================

    /// <summary>
    /// Audit details of connection: Host, Port, Effective User, Library List
    /// </summary>
    public ConnectionAuditInfo ConnectionAudit { get; set; } = new();

    /// <summary>
    /// AS400 Server Job Details: Job Number, User, Job Name (e.g. 123456/QUSER/QZDASOINIT)
    /// </summary>
    public JobIdentificationInfo JobIdentification { get; set; } = new();

    /// <summary>
    /// Captured job log entries from QSYS2.JOBLOG_INFO()
    /// </summary>
    public List<JobLogEntry> JobLogs { get; set; } = new();

    /// <summary>
    /// Indicates whether a terminal / display file hang was detected
    /// </summary>
    public bool IsHangDetected { get; set; }

    /// <summary>
    /// Detailed diagnostic warning text (e.g. green-screen wait, DSPF, *LDA issue)
    /// </summary>
    public string? HangDiagnosticWarning { get; set; }

    /// <summary>
    /// Actionable remediation advice tailored for the AS400 COBOL development team
    /// </summary>
    public List<string> RemediationAdvice { get; set; } = new();

    /// <summary>
    /// Raw SQL table results if Method D was executed
    /// </summary>
    public SqlQueryResult? SqlResult { get; set; }
}

public class ConnectionAuditInfo
{
    public string TargetHost { get; set; } = string.Empty;
    public int TargetPort { get; set; }
    public string EffectiveUser { get; set; } = string.Empty;
    public string AppliedLibraryList { get; set; } = string.Empty;
    public string NamingMode { get; set; } = string.Empty;
    public string DriverUsed { get; set; } = string.Empty;
    public string ConnectionStringMasked { get; set; } = string.Empty;
}

public class JobIdentificationInfo
{
    public string JobNumber { get; set; } = string.Empty;
    public string JobUser { get; set; } = string.Empty;
    public string JobName { get; set; } = "QZDASOINIT"; // QZDASOINIT for DB2 host server, QP0ZSPWP for PASE/SSH
    public string Subsystem { get; set; } = "QUSRWRK";
    public string FullJobString => string.IsNullOrEmpty(JobNumber) ? "N/A" : $"{JobNumber}/{JobUser}/{JobName}";
}

public class SqlQueryResult
{
    public List<string> ColumnNames { get; set; } = new();
    public List<List<string>> Rows { get; set; } = new();
    public int RowsAffected { get; set; }
}
