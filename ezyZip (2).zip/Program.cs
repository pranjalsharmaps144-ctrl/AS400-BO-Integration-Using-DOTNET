using IbmAs400Workbench.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();

// Register application services for IBM i direct execution
builder.Services.AddSingleton<ICobolBufferService, CobolBufferService>();
builder.Services.AddScoped<IIbmBoExecutionService, IbmBoExecutionService>();

// Enable CORS if hosted behind reverse proxy or corporate portal
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseCors("AllowAll");
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=BoWorkbench}/{action=Index}/{id?}");

app.Run();
